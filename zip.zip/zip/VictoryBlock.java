import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class VictoryBlock extends GameObject
{//GameObject
   
   public VictoryBlock(int x,int y,Color c)
   {
   super();
   }

}//GameObject