import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Block extends GameObject
{//GameObject
   
   public Block(int x,int y,Color c)
   {
   super();
   }

}//GameObject